import React from "react";

const PaymentSuccess = () => {
  return (
    <div
      style={{
        display: "flex",
        justifyContent: "center",
        alignItems: "center",

      }}
    >
      <div style={{position:"relative",marginTop:300,fontSize:23}}>
        <h2>ORDER SUCCESSFULL</h2>
      </div>
    </div>
  );
};

export default PaymentSuccess;
