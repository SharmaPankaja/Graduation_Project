# AmazonClone
The project is clone of The biggest shopping platform in the world is Amazon. have a same features like Amazon like Login and Signup for user security.
user can add product on there my cart section and also can buy product.have search functionality can search product by there names. and the main part is payment gateway for that user razorpay. and many more

## How to Start Project
step- 1  first clone the project from GitHub

step- 2   goto client Directory using cd client command 

         - npm i (install dependencys)
         - run  npm start
         
step- 3   goto server Directory using cd server command   

         - npm i (install dependencys)
         - run nodemon

