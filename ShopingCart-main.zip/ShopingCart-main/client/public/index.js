const obj={
    age:20,
    name:"shiva"
}
console.log(obj.age=30);
obj.name="raju"
obj.city="nanded"
obj.city="latur"
console.log(obj["age"]);